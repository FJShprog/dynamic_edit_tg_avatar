import json
import os
import sqlite3

class EditData:
        def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs
                self.path = ""
        def folder_create_true(self, user_id):
                import os
                try:
                        os.mkdir("database/users/" + str(user_id))
                except Exception as e:
                        print(e)
                        return True

        def create_table_bool_avatar_set(self):
                con = sqlite3.connect("database/users_condition.db")
                cur = con.cursor()
                cur.execute(
                        """
                        CREATE TABLE IF NOT EXISTS user_conditions(
                                user_id INTEGER PRIMARY KEY,
                                condition INTEGER
                        )
                        """
                )
                con.commit()
                con.close()

        def create_user_set_avatar(self, user_id: int, condition: int):
                """
                :param user_id: ID user(telegram)
                :param condition: [0 - False, 1 - True]
                :return: result
                """
                con = sqlite3.connect("database/users_condition.db")
                cur = con.cursor()
                try:
                        cur.execute("""
                                INSERT INTO user_conditions(
                                        user_id,
                                        condition  
                                ) VALUES (?, ?)
                        """, (user_id, condition))
                        con.commit()
                        con.close()
                        return "user create"
                except:
                        con.commit()
                        con.close()
                        return "This user already exists"

        def get_condition(self):
            con = sqlite3.connect("database/users_condition.db")
            cur = con.cursor()
            cur.execute("""
                    SELECT * FROM user_conditions
                    """)
            rows = cur.fetchall()
            con.commit()
            con.close()
            lst=[]
            for row in rows:
                lst.append(row)

            return lst


        def update_user_set_avatar_condition(self, user_id: int, condition: int):
                """
                :param user_id:
                :param condition: 1 - True, 2 - False
                :return: result
                """
                con = sqlite3.connect("database/users_condition.db")
                cur = con.cursor()
                cur.execute('''
                        UPDATE user_conditions
                                SET condition = ?
                                WHERE user_id = ?
                ''', (condition, user_id))
                con.commit()
                con.close()

        def create_db_users(self):
                con = sqlite3.connect("database/users/users.db")
                cur = con.cursor()
                cur.execute("""
                        CREATE TABLE IF NOT EXISTS users(
                        user_id INTEGER PRIMARY KEY,
                        user_name STRING,
                        first_name STRING,
                        surname STRING,
                        phone STRING,
                        premium_status STRING,
                        list_accounts STRING,
                        data_register STRING,
                        condition INTEGER
                        )
                """)
                con.commit()
                cur.close()

        def delete_user_auth(self, user_id):
                try:
                        os.remove(f"./users/{user_id}/{user_id}.session")
                except:
                        return "Don't have this user"


        def json_image_settings(self, user_id):
                import json
                set_user_settings = {
                        "time": True,
                        "data": True,
                        "font_time": ["DS", "English Rose"],
                        "font_data": ["DS", "English Rose"],
                        "font_time_settings": (255, 0, 10),
                        "font_data_settings": (255, 0, 100),
                        "time_xy": (175, 260),
                        "data_xy": (100, 180),
                        "time_size": 60,
                        "data_size": 60,
                        "background": "black",
                        "img_background": None,
                        "img_background_blur": 10,
                        "img_background_category": []
                }
                path = f"database/users/{user_id}/"
                with open(path+"user_setting.json", 'w', encoding="utf-8") as file:
                        json.dump(set_user_settings, file)

        def get_json_user(self, user_id):
                # file = self.kwargs.get("file")
                path = f"database/users/{user_id}/user_setting.json"
                with open(path, 'r') as file:
                        return json.load(file)

        def check_user_database(self, user_id):
                user_session = os.path.exists(f'database/users/{user_id}/user_session.session')
                user_json_setting = os.path.exists(f'database/users/{user_id}/user_setting.json')
                return {"user_session": user_session, "user_json_setting": user_json_setting}

