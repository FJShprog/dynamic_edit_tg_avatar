import time

from aiogram import Dispatcher, Bot
import asyncio
from .handler import handler
from database.EditData import EditData
from bot.set_avatar import run_avatar_set
from bot.handler.setava import ProfilePhotoUpdater
async def bot():
    TOKEN = '6809255966:AAH9Db-gnzf6VLXL35gkAWAhnmbtp6RWDQo'
    bot = Bot(token=TOKEN)
    dp = Dispatcher()
    asyncio.create_task(set_avatar_from_db(dp))
    dp.include_router(handler.router)
    await bot.delete_webhook(True)
    await dp.start_polling(bot)
    return bot

async def set_avatar_from_db(dp):
    EditData()
    while True:
        await run_avatar_set()
        await asyncio.sleep(60)



async def true_time():
    pass

async def false_time():
    pass

def run_project():
    asyncio.run(bot())