import time

from aiogram import Dispatcher, Bot
import asyncio
from .handler import handler
from database.EditData import EditData
from bot.set_avatar import run_avatar_set
async def bot(TOKEN):
    bot = Bot(token=TOKEN)
    dp = Dispatcher()
    asyncio.create_task(set_avatar_from_db(dp))
    dp.include_router(handler.router)
    await bot.delete_webhook(True)
    await dp.start_polling(bot)
    return bot

async def set_avatar_from_db(dp):
    while True:
        await run_avatar_set()
        await asyncio.sleep(60)


def run_project(TOKEN):
    asyncio.run(bot(TOKEN))