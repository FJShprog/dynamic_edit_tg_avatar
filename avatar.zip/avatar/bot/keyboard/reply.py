from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove
def keyboards_menu():
    keys = [
        [KeyboardButton(text="start🚀")],
        [KeyboardButton(text="stop⛔")],
        [KeyboardButton(text="Settings⚙")]
    ]
    markup = ReplyKeyboardMarkup(keyboard=keys,resize_keyboard=True, input_field_placeholder="Select ⬇️⬇️")
    return markup

def keyboards_settings():
    keys = [
        [KeyboardButton(text="SetNumber🔢", request_contact=True)],
        [KeyboardButton(text="Avatar⬇️😐")],
        [KeyboardButton(text="User Avatar Setting📃")],
        [KeyboardButton(text="Back🔙")]
    ]
    markup = ReplyKeyboardMarkup(keyboard=keys, resize_keyboard=True, input_field_placeholder="Select ⬇️⬇️")
    return markup


def user_register():
    keys = []

def key_edit_avatar():
    pass