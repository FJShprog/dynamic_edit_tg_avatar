from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

def numbers():
    ls_nums = [InlineKeyboardButton(num) for num in range(10)]
    markup = InlineKeyboardMarkup(ls_nums)