import asyncio
from database.EditData import EditData
from image.image_creator import create_image
from concurrent.futures import ThreadPoolExecutor
from bot.handler.setava import UserTelegram, ProfilePhotoUpdater
async def run_avatar_set():
    list_users = await get_users_condition()
    thread_run(list_users)


async def get_users_condition() -> list:
    users_condition = EditData().get_condition()
    ls_sets = []
    for user_id, condition in users_condition:
        result = EditData().check_user_database(user_id).get("user_session")
        if result:
            try:
                ls_sets.append(user_id if condition == 1 else None)
                print(ls_sets)
            except Exception as e:
                print("Error. set_avatar.py, get_users_condition:", e)
    if not ls_sets:
        ls_sets.append(1)
    return ls_sets


def thread_run(users_list):
    with ThreadPoolExecutor(max_workers=len(users_list)) as exc:
        exc.map(run_async_create, users_list)

def run_async_create(user_id):
    asyncio.run(create_image_and_set(user_id))
async def create_image_and_set(user_id):
    try:
        print("create_image->")
        read_user_json = EditData().get_json_user(user_id)
        image = (create_image(
            time=read_user_json.get("time"),
            data=read_user_json.get("data"),
            font_time=read_user_json.get("font_time")[0],
            font_data=read_user_json.get("font_data")[0],
            font_time_settings=read_user_json.get("font_time_settings"),
            font_data_settings=read_user_json.get("font_data_settings"),
            time_xy=read_user_json.get("time_xy"),
            data_xy=read_user_json.get("data_xy"),
            time_size=read_user_json.get("time_size"),
            data_size=read_user_json.get("data_size"),
            background=read_user_json.get("background"),
            img_background=read_user_json.get("img_background"),
            img_background_blur=read_user_json.get("img_background_blur"),
        ))
        image.save(f"database/users/{user_id}/time.jpeg")
    except Exception as e:
        print("crate_image_and_set:", user_id, e)

    cl1 = await ProfilePhotoUpdater(user_id).start_client()
    await asyncio.sleep(5)
    await ProfilePhotoUpdater(user_id).process(cl1)







