import random
from aiogram import Bot
from aiogram import Router, F, Bot, types
from aiogram.types import Message, FSInputFile
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from bot.keyboard import keyboards_menu, keyboards_settings
from database.EditData import EditData
from bot.handler.setava import UserTelegram
import asyncio
router = Router()
nums = {
    1:"one",
    2:"two",
    3:"three",
    4:"four",
    5:"five",
    6:"six",
    7:"seven",
    8:"eight",
    9:"nine",
    0:"zero"
}
class RegisterUser(StatesGroup):
    waiting_for_code = State()
@router.message(Command("start"))
async def main_menu(message: Message):
    user_id = message.from_user.id
    EditData().folder_create_true(user_id=user_id)
    EditData().json_image_settings(user_id=user_id)
    EditData().create_user_set_avatar(user_id, 0)
    await message.answer("Hi", reply_markup=keyboards_menu())

bot = Bot("6809255966:AAH9Db-gnzf6VLXL35gkAWAhnmbtp6RWDQo")
@router.message(F.text == "start🚀", StateFilter(None))
async def start_set(message: Message):
    await message.delete()
    check = EditData().check_user_database(message.from_user.id)
    if check.get("user_session"):
        await message.answer("start🚀 -> ")
        EditData().update_user_set_avatar_condition(user_id=message.from_user.id, condition=1)

@router.message(F.contact)
async def contact_received(message: types.Message, state: FSMContext):
    # code_hash = await UserTelegram(message.from_user.id).register_user_send(message.contact.phone_number)
    # await UserTelegram(message.from_user.id).register_user_accept(input("Code phone: "), message.contact.phone_number, code_hash)
    global contact
    global code_hash
    contact = message.contact
    await state.set_state(RegisterUser.waiting_for_code)
    await message.answer('Введите код из SMS, в виде текста на английскм языке\n"three five..."')
    code_hash = await UserTelegram(user_id=message.from_user.id).register_user_send(phone=contact.phone_number)
    await asyncio.sleep(5)

@router.message(RegisterUser.waiting_for_code)
async def code_received(message: types.Message, state: FSMContext):
    await asyncio.sleep(random.randint(4, 7))
    ls=[]
    ms = message.text.split(' ')
    for num in ms:
        for c,v in nums.items():
            if num.lower()==v:
                ls.append(str(c))
    ls = int(''.join(ls))
    print(ls)
    await UserTelegram(user_id=message.from_user.id).register_user_accept(ls, contact.phone_number, code_hash)
    await state.clear()
    await message.answer("Ваша сессия сохранена!")








@router.message(F.text=="Settings⚙")
async def settings(message: Message):
    await message.delete()
    await message.answer("Settings⚙", reply_markup=keyboards_settings())
@router.message(F.text=='Avatar⬇️😐')
async def avatar_settings(message: Message):
    await message.delete()
    await message.answer(message.text)
    await message.answer_document(FSInputFile(
        f'database/user_setting.json'))

@router.message(F.text=='User Avatar Setting📃')
async def avatar_settings(message: Message):
    await message.delete()
    await message.answer(message.text)
    await message.answer_document(FSInputFile(
        f'database/users/{message.from_user.id}/user_setting.json'))


@router.message(F.document)
async def read_document_user(message: Message, state: FSMContext):
    document = message.document.file_id
    doc = await bot.get_file(document)
    print("Save", doc)
    await bot.download(doc, f"database/users/{message.from_user.id}/user_setting.json")

@router.message(F.text=="stop⛔")
async def stop_set(message: Message):
    await message.delete()
    await message.answer(message.text)
@router.message(F.text=="Back🔙")
async def main_menu(message: Message):
    await message.delete()
    await message.answer("Back🔙", reply_markup=keyboards_menu())




