from telethon import TelegramClient, sync
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
from telethon.tl.functions.account import GetAuthorizationsRequest
class UserTelegram:
    def __init__(self, user_id: int = None, user_path=None, path_image=None, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs
        self.app = 25644729
        self.api_hash = "2467073de56ae82e36c1ae529210d039"
        self.TOKEN = '6809255966:AAH9Db-gnzf6VLXL35gkAWAhnmbtp6RWDQo'
        self.user_id = user_id
        self.user_path = user_path if user_path else f"./database/users/{self.user_id}/user_session"
        self.client = TelegramClient(self.user_path, api_id=self.app, api_hash=self.api_hash)
        self.client_disconnect: bool = True
        self.path_image = f"database/users/{user_id}/time.jpeg"


    async def register_user_send(self, phone):
        # phone = self.kwargs.get("phone")
        # user_id = self.kwargs.get("user_id")
        try:
            await self.client.connect()
            result = await self.client.send_code_request(phone)
            phone_code_hash = result.phone_code_hash
            await self.client.disconnect()
            return phone_code_hash
        except Exception as ex:
            print(f'{self.user_id}: {ex}')
            from database.EditData import EditData
            EditData().delete_user_auth(user_id=self.user_id)
            await self.client.connect()
            result = await self.client.send_code_request(phone)
            phone_code_hash = result.phone_code_hash
            await self.client.disconnect()
            return phone_code_hash


    async def register_user_accept(self, code_phone, phone, phone_hash):
        # code_phone = self.kwargs.get("code")
        # phone = self.kwargs.get("phone")
        # user_id = self.kwargs.get("user_id")
        # phone_hash = self.kwargs.get('phone_hash')
        try:
            await self.client.connect()
            await self.client.sign_in(phone=phone, code=code_phone, phone_code_hash=phone_hash)
            await self.client.disconnect()
        except Exception as ex:
            print(f'{self.user_id}: {ex}')
            return f'{self.user_id}: {ex}'


    async def requests_user(self):
        # user_id = self.kwargs.get("user_id")
        try:
            await self.client.connect()
            get_user = await self.client.get_me()
            print(f"{'--'*100}\n{get_user}\n{'--'*100}")
            await self.client.disconnect()
            return get_user
        except Exception as ex:
            print(f'{self.user_id}: {ex}')
            return f'{self.user_id}: {ex}'

    async def set_avatar(self, path_image):
        try:
            photos = await self.client.get_profile_photos("me")
            await self.client(DeletePhotosRequest(photos))
            file = await self.client.upload_file(path_image)
            await self.client(UploadProfilePhotoRequest(file=file))
        except Exception as ex:
            print(f'{self.user_id}: {ex}')
            return f'{self.user_id}: {ex}'

    async def delete_avatar(self):
        try:
            await self.client.connect()
            photos = await self.client.get_profile_photos("me")
            await self.client(DeletePhotosRequest(photos))
        except Exception as ex:
            print(f'{self.user_id}: {ex}')
            return f'{self.user_id}: {ex}'

    async def get_users_sessions(self):
        await self.client.connect()
        sessions = await self.client(GetAuthorizationsRequest())
        await self.client.disconnect()
        return sessions.authorizations


class ProfilePhotoUpdater(UserTelegram):
    async def start_client(self):
        return self.client.start()
    async def proces(self):
        try:
            await self.client.connect()
            photos = await self.client.get_profile_photos("me")
            await self.client(DeletePhotosRequest(photos))
            file = await self.client.upload_file(self.path_image)
            await self.client(UploadProfilePhotoRequest(file=file))
            await self.client.disconnect()
        except Exception as ex:
            await self.client.disconnect()
            print(f'{self.user_id}: {ex}')
            return f'{self.user_id}: {ex}'
