from bot import bot
import argparse


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Bot Token')
    parser.add_argument('--token', type=str, required=True, help='BOT TOKEN')
    args = parser.parse_args()
    bot.run_project(TOKEN=args.token)




