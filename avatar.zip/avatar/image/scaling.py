def scale(image: str = None):
    from PIL import Image
    #Scale and Upscale image