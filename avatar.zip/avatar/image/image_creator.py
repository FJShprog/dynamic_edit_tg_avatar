import datetime
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os


def create_image(
                time: bool = True,
                data: bool = True,
                font_time: str = "DS",
                font_data: str = 'DS',
                font_time_settings: tuple = (255, 0, 0),
                font_data_settings: tuple = (255, 1, 50),
                time_xy: tuple = (175, 260),
                data_xy: tuple = (100, 180),
                time_size: int = 60,
                data_size: int = 60,
                background: str = "black",
                img_background: str = None,
                img_background_blur: int = 10):

    font_time_settings = (font_time_settings[0],
                          font_time_settings[1],
                          font_time_settings[2])
    font_data_settings = (font_data_settings[0],
                          font_data_settings[1],
                          font_data_settings[2])
    time_xy = (time_xy[0],
               time_xy[1])
    data_xy = (data_xy[0],
               data_xy[1])

    try:
        if img_background:
            img = Image.open(img_background).filter(ImageFilter.GaussianBlur(img_background_blur))
        else:
            img = Image.new(mode = ('RGBA' if len(font_data_settings and font_time_settings) >= 4 else "RGB"),
                            size=(500, 500),
                            color=background)
    except:
        img = Image.new(mode = ('RGBA' if len(font_data_settings and font_time_settings)>=4 else "RGB"),
                        size=(500, 500),
                        color='black')

    # Create object for Draw
    d = ImageDraw.Draw(img)
    data_now = datetime.datetime.now()
    ttf_path = {
        "nt": os.getcwd().replace("\\", "\\\\")+"\\\\image\\\\datattf\\\\",
        "posix": os.getcwd()+'/image/datattf/'
    }

    if time:
        font_hour = ImageFont.truetype(font=ttf_path[os.name]+"{}.ttf".format(font_time),
                                       size=time_size)
        d.text(xy=time_xy, text=str(f"{data_now.hour}:{data_now.minute}"), fill=font_time_settings, font=font_hour)
    if data:
        font_data = ImageFont.truetype(font=ttf_path[os.name]+"{}.ttf".format(font_data),
                                       size=data_size)
        d.text(xy=data_xy,
               text=str(f"{data_now.date()}"),
               fill=font_data_settings,
               font=font_data)
    return img




# create_image(True, False, time_xy=(180,190), font_time="DS", font_data_settings=(255,12,12), background='whidte', img_background='qwe',time_size=100).save('123.jpeg')
